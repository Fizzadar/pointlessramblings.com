# PNG Optimiser Comparison
# Author: Nick Barrett
# Blog Post: http://pointlessramblings.com/posts/pngquant_vs_pngcrush_vs_optipng_vs_pngnq/

## Directories:

+ originals/: images before being exported as png via photoshop
+ before/: images after photoshop export, all png
+ after/<optimizer>/: resulting images from the relevant optimiser