## Before

    total 21440
    3006 14 Jan 21:30 23.png
    6886310 14 Jan 21:30 castle.png
    1370632 14 Jan 21:30 firefox-flat.png
    796694 14 Jan 21:28 firefox-shiny.png
    135480 14 Jan 21:30 github.png
    499812 14 Jan 21:30 gmod.png
    25009 14 Jan 21:30 luawa.png
    1237375 14 Jan 21:30 screenshot.png


## pngquant

    total 8048
    1057 14 Jan 21:33 23.png
    2602142 14 Jan 21:33 castle.png
    473131 14 Jan 21:33 firefox-flat.png
    451024 14 Jan 21:33 firefox-shiny.png
    49397 14 Jan 21:33 github.png
    168896 14 Jan 21:33 gmod.png
    6572 14 Jan 21:33 luawa.png
    347854 14 Jan 21:33 screenshot.png


## pngcrush

    total 20592
    3004 14 Jan 21:38 23.png
    6627173 14 Jan 21:38 castle.png
    1337125 14 Jan 21:38 firefox-flat.png
    787966 14 Jan 21:39 firefox-shiny.png
    119378 14 Jan 21:39 github.png
    494530 14 Jan 21:39 gmod.png
    22582 14 Jan 21:39 luawa.png
    1138448 14 Jan 21:39 screenshot.png


## optipng

    total 20224
    1065 14 Jan 21:40 23.png
    6458316 14 Jan 21:46 castle.png
    1337101 14 Jan 21:48 firefox-flat.png
    777596 14 Jan 21:50 firefox-shiny.png
    118047 14 Jan 21:51 github.png
    493635 14 Jan 21:51 gmod.png
    22581 14 Jan 21:51 luawa.png
    1133850 14 Jan 21:53 screenshot.png


## pngnq

    total 7752
    2278 14 Jan 21:43 23.png
    2812069 14 Jan 21:43 castle.png
    454944 14 Jan 21:43 firefox-flat.png
    160342 14 Jan 21:43 firefox-shiny.png
    49007 14 Jan 21:43 github.png
    159135 14 Jan 21:43 gmod.png
    6438 14 Jan 21:43 luawa.png
    307872 14 Jan 21:43 screenshot.png